#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 22 18:03:47 2020

@author: taylorbyers
"""
import pandas as pd

#Doing initial data investigation
df = pd.read_csv("/Users/taylorbyers/Documents/Masters in Data Science/MCIS-540/Course Project/est16_pa.txt", delimiter= '\s+', index_col=False, header=None)
#print(df)

#Creating an empty list to contain all of the information we want from the large dataset
pa_counties = []
#Opening the txt file in reading mode
x = open("/Users/taylorbyers/Documents/Masters in Data Science/MCIS-540/Course Project/est16_pa.txt", 'r')
print(x)
#Creating a dictionary of the important data that will be used in the program
for line in x.readlines():
    d = {}
    data = ' '.join(line.split()).split()
    d["Count"] = int(data[8])
    d["Percentage"] = float(data[11])
    d["Median_Income"] = float(data[20])
    d["Name"] = line[193:239].rstrip(' ')
    pa_counties.append(d)

#Sorting by Perentage from Lowest to Highest so finding these counties require simplier coding
sorted_data = sorted(pa_counties, key=lambda x: x["Percentage"])

#Finding Highest Percentage County (Since this was sorted, it will be the last entry)
def print_highest_data(pa_counties):
    print("\nCounty with Highest Percentage of Children in Poverty:")
    print_data(pa_counties[-1])

#Finding Lowest Percentage County (Since this was sorted, it will be the first entry)
def print_lowest_data(pa_counties):
    print("County with Lowest Percentage of Children in Poverty:")
    print_data(pa_counties[0])

#Finding the Information for User Input County
def print_county_data(pa_counties):
    user_county = input("Please, enter a Pennsylvania County to display its poverty information. If you enter a county that is not in Pennsylvania, you will be asked to enter another county. (You may enter 'q' or 'quit' to exit the program): ").lower()
    
    while user_county != "q" and user_county != "quit" and user_county != "Q" and user_county != "Quit":
        for x in pa_counties:
            if user_county in x["Name"].lower():
                print_data(x)
                break
        user_county = input("Please, enter a Pennsylvania County to display its poverty information (You may enter 'q' or 'quit' to exit the program): ").lower()
    print("\nThe program has now ended.")

#Printing Out Data Needed for Highest, Lowest, and Input Counties
def print_data(county):
    print("County Name: {}".format(county["Name"]))
    print("Percentage of Children in Poverty: {}".format(county["Percentage"]))
    print("Number of Children in Poverty: {}".format(county["Count"]))
    print("Median Household Income: {}".format(county["Median_Income"]))
    print()

#Calling Highest County Function
print_highest_data(sorted_data)

#Calling Lowest County Function
print_lowest_data(sorted_data)

#Calling User Input County Function
print_county_data(sorted_data)

        
        